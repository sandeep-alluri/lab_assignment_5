from django.urls import path
from helloapp.views import MyView

urlpatterns = [
    path('', MyView.as_view()),
]