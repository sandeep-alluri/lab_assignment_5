import json
from django.views import View
from django.http import JsonResponse
from django.http import HttpResponse

class index(View):
    def myview(request):
    if request.method == "POST":
        form = MyForm(request.GET)
        if form.is_valid():
            data = {
            "message": "Hello world"
            }
            # <process form cleaned data>
            return HttpResponse(json.dumps(data), content_type = "application/json")
    else:
        form = MyForm(initial={'key': 'value'})
        data = {
            "message": "Somthing went wrong"
        }
        return HttpResponse(json.dumps(data), content_type = "application/json")
    

        